Animationen ligger i mp4 og kr�ver derfor et ekstra video decoder for at afspeiller.
Alternativt en kompatibel afstiller, vi anbefaler vlc media player.

Yderligere kan animationen findes p� https://www.youtube.com/watch?v=aIQuX2SlIM4&list=UUwazfqDM1AunJ1vGyhPoIwA&index=1
Og ellers ligger den ogs� som en after effects fil i mappen.